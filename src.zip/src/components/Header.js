import React from "react";

function Header() {
    return (
        <div className={"header"}>
            HEADER
        </div>
    );
}

export default Header;