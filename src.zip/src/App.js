import React from 'react';
import './App.css';

import TypingPage from "./pages/TypingPage";

function App() {
    return (
        <div className="App">
            <TypingPage />
        </div>
    );
}

export default App;